from mtsda.data import mtsda
import numpy as np

# Initialise a data object holding data with 50000 samples,
# 10 processes, and 5 replications.
mydata = np.arange(50000).reshape((1000, 10, 5))
dat = Data(mydata, dim_order='spr')

# Initialise a data object holding data with 5 processes and
# 5000 samples
mydata = np.arange(5000).reshape((5, 1000))
dat = Data(mydata, dim_order='ps')

# Initialise a data object holding data with 1 process and
# 1000 samples
mydata = np.arange(1000)
dat = Data(mydata, dim_order='s')

import pandas as pd
df = pd.DataFrame(
    {'col1': np.random.rand(100), 'col2': np.random.rand(100)})
data = Data(df, dim_order='sp')
# Adding data with properties: 2 processes, 100 samples, 1 replications
# overwriting existing data